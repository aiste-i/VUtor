﻿using Castle.DynamicProxy;
using System;

namespace Aspects;

class Program
{
    static void Main()
    {
        var generator = new ProxyGenerator();
        var interceptor = new LogAttributeInterceptor();

        var service = generator.CreateClassProxy<MyService>(interceptor);

        // Interception will occur for marked methods
        service.MethodToIntercept();

        // No interception for the regular method
        service.RegularMethod();
    }
}
