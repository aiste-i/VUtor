namespace Aspects;

public class MyService
{
    [Log]
    public virtual void MethodToIntercept()
    {
        Console.WriteLine("Inside MethodToIntercept");

        throw new Exception();
    }

    public void RegularMethod()
    {
        Console.WriteLine("Inside RegularMethod");
    }
}
