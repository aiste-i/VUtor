namespace Aspects;

[AttributeUsage(AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
public sealed class LogAttribute : Attribute { }
