using Castle.DynamicProxy;
using System;

namespace Aspects;

public class LogAttributeInterceptor : IInterceptor
{
    public void Intercept(IInvocation invocation)
    {
        // Check if the method is marked with the LogAttribute
        if (invocation.Method.GetCustomAttributes(typeof(LogAttribute), true).Length > 0)
        {
            try
            {
                invocation.Proceed();
            }
            catch
            {
                Console.WriteLine("Exception occured");
            }
        }
    }
}
